// src/pages/SettingsPage.tsx
export default function SettingsPage() {
    return (
      <div className="p-8">
        <h1 className="text-2xl font-bold">Einstellungen</h1>
        <p>Hier können Admins Systemeinstellungen verwalten.</p>
      </div>
    );
  }
  