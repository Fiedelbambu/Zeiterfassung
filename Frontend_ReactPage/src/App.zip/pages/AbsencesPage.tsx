export default function AbsencesPage() {
    return (
      <div className="p-8">
        <h1 className="text-2xl font-bold">Benutzerverwaltung</h1>
        <p>Hier können Abwesenheiten angelegt und verwaltet werden.</p>
      </div>
    );
  }
  