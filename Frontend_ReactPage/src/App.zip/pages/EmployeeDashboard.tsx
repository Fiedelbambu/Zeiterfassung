export default function EmployeeDashboard() {
    return (
      <div className="p-8">
        <h1 className="text-3xl font-bold mb-6">Willkommen im Mitarbeiter-Dashboard</h1>
        {/* Hier später Buttons für Zeiterfassung, Anträge usw. */}
      </div>
    );
  }
  