import { useEffect } from "react";
import { getToken } from "../utils/auth";
import i18n from "../i18n";

export function useInitLanguage() {
  useEffect(() => {
    const loadLanguage = async () => {
      try {
        const res = await fetch("https://localhost:7123/api/settings", {
          headers: { Authorization: `Bearer ${getToken()}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.language && i18n.language !== data.language) {
            i18n.changeLanguage(data.language);
            console.log("Sprache gesetzt auf:", data.language);
          }
        }
      } catch (err) {
        console.warn("Sprache konnte nicht geladen werden:", err);
      }
    };

    loadLanguage();
  }, []);
}
