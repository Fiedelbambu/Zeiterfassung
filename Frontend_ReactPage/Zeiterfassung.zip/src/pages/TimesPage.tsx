
export default function TimesPage() {
    return (
      <div className="p-8">
        <h1 className="text-2xl font-bold">Benutzerverwaltung</h1>
        <p>Hier können Arbeitszeiten angelegt und verwaltet werden.</p>
      </div>
    );
  }
  