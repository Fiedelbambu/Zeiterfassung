export default function ReportsPage() {
    return (
      <div className="p-8">
        <h1 className="text-2xl font-bold">Benutzerverwaltung</h1>
        <p>Hier können Benutzer angelegt und verwaltet werden.</p>
      </div>
    );
  }
  